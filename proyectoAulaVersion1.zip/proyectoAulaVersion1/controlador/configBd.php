<?php
$GLOBALS['serv']="localhost";
$GLOBALS['usua']="root";
$GLOBALS['pass']="";
$GLOBALS['bdat']="bdproyectoaulav1";

?>